function goBack() {
  window.location.href = 'pagina_em_branco.html2';
}

function toggleMenu() {
  var popupMenu = document.getElementById('popupMenu');
  if (popupMenu.style.display === 'block') {
      popupMenu.style.display = 'none';
  } else {
      popupMenu.style.display = 'block';
  }
}

function navigateTo(page) {
  window.location.href = page;
}
